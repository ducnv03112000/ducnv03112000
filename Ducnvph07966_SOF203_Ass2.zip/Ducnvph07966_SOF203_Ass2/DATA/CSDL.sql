﻿Create database CSDL				
go
------------------------------
use CSDL
go
-------------------
-------STUDENTS-----------------------------
	IF  EXISTS (SELECT * FROM SYSOBJECTS  WHERE Name = N'STUDENTS')					
	Drop table STUDENTS					
	Go					
	Create table STUDENTS(
		MASV NVARCHAR(50) NOT NULL,
		HOTEN NVARCHAR(50) NULL,
		EMAIL NVARCHAR(50) NULL,
		SODT NVARCHAR(15) NULL,
		GIOITINH BIT NULL,
		DIACHI NVARCHAR(50) NULL,
		HINH NVARCHAR(MAX) NULL,
		CONSTRAINT PK_STUDENTS PRIMARY KEY (MASV)	
	)
	-------GRADE--------------------------------
	IF  EXISTS (SELECT * FROM SYSOBJECTS  WHERE Name = N'GRADE')					
	Drop table GRADE					
	Go					
	Create table GRADE(
		ID INT  NOT NULL,
		MASV NVARCHAR(50) NOT NULL,
		TIENGANH FLOAT NULL,
		TINHOC FLOAT NULL,
		GDTC FLOAT NULL,
		CONSTRAINT PK_GRADE PRIMARY KEY (ID),
		CONSTRAINT FK_GRADE_STUDENTS FOREIGN KEY(MASV) REFERENCES STUDENTS
	)
	--------USERS-------------------------------
	IF  EXISTS (SELECT * FROM SYSOBJECTS  WHERE Name = N'USERS')					
	Drop table USERS					
	Go					
	Create table USERS(
		USERNAME NVARCHAR(50) NOT NULL,
		PASSWORDD NVARCHAR(50) NULL,
		ROLE NVARCHAR(50) NULL,
		CONSTRAINT PK_USERS PRIMARY KEY(USERNAME)
	)

	DELETE FROM USERS
insert into USERS values(N'ducnv',N'ph123',N'student')
insert into USERS values(N'dungnt',N'ph124',N'student')
insert into USERS values(N'hoangnt',N'ph125',N'student')
insert into USERS values(N'manhnv',N'ph126',N'student')
insert into USERS values(N'tungtt',N'ph127',N'student')
insert into USERS values(N'huylv',N'ph128',N'student')
insert into USERS values(N'loantt',N'ph001',N'teacher')
insert into USERS values(N'hieutt',N'ph002',N'teacher')


DELETE FROM GRADE
insert into GRADE values(01,N'ph123',10,9,9)
insert into GRADE values(02,N'ph124',5,8,9)
insert into GRADE values(03,N'ph125',7,7,9)
insert into GRADE values(04,N'ph126',7,8,6)
insert into GRADE values(05,N'ph127',7,8,7)
insert into GRADE values(06,N'ph128',7,8,8)
insert into GRADE values(07,N'01',9,8,9)
insert into GRADE values(08,N'02',8,8,9)

DELETE FROM STUDENTS
insert into STUDENTS values(N'ph123',N'Nguyễn Việt Đức',N'ducnv@gmail.com',0312123125,1,N'Cầu Giấy-Hà Nội','src\\Image\\images1\\LyXD.jpg')
insert into STUDENTS values(N'ph124',N'Nguyễn Thùy Dung',N'dungnt@gmail.com',0312123625,0,N'Bắc Từ Liêm-Hà Nội','Image\\images1\\user.jpg')
insert into STUDENTS values(N'ph125',N'Nguyễn Thanh Hoàng',N'hoangnt@gmail.com',0312423125,1,N'Đống Đa-Hà Nội','Image\\images1\\user.jpg')
insert into STUDENTS values(N'ph126',N'Nguyễn Văn Mạnh',N'manhnv@gmail.com',0312123185,1,N'Ba Đình-Hà Nội','Image\\images1\\user.jpg')
insert into STUDENTS values(N'ph127',N'Trần Thanh Tùng',N'tungtt@gmail.com',0312123925,1,N'Thanh Xuân-Hà Nội','Image\\images1\\user.jpg')
insert into STUDENTS values(N'ph128',N'Lê Văn Huy',N'huylv@gmail.com',0312123128,1,N'Nam Từ Liêm-Hà Nội','Image\\images1\\user.jpg')
insert into STUDENTS values(N'01',N'Trần Thị Loan',N'thaolm@gmail.com',0312523125,0,N'Hai Bà Trưng-Hà Nội','Image\\images1\\user.jpg')
insert into STUDENTS values(N'02',N'Trần Thị Hiếu',N'hieutt@gmail.com',0312923125,0,N'Long Biên-Hà Nội','Image\\images1\\user.jpg')