
package ducnvph07966_sof203_ass2;


public class grade {
    
    public String masv, name;
    public double anh, tin, gdtc, avg;
    public int id;

    public grade() {
    }

    public grade(String masv, String name, double anh, double tin, double gdtc, double avg, int id) {
        this.masv = masv;
        this.name = name;
        this.anh = anh;
        this.tin = tin;
        this.gdtc = gdtc;
        this.avg = avg;
        this.id = id;
    }

    public String getMasv() {
        return masv;
    }

    public void setMasv(String masv) {
        this.masv = masv;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getAnh() {
        return anh;
    }

    public void setAnh(double anh) {
        this.anh = anh;
    }

    public double getTin() {
        return tin;
    }

    public void setTin(double tin) {
        this.tin = tin;
    }

    public double getGdtc() {
        return gdtc;
    }

    public void setGdtc(double gdtc) {
        this.gdtc = gdtc;
    }

    public double getAvg() {
        return avg;
    }

    public void setAvg(double avg) {
        this.avg = avg;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "grade{" + "masv=" + masv + ", name=" + name + ", anh=" + anh + ", tin=" + tin + ", gdtc=" + gdtc + ", avg=" + avg + ", id=" + id + '}';
    }
    
}
