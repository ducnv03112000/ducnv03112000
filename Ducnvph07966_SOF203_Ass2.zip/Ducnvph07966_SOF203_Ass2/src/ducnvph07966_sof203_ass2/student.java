package ducnvph07966_sof203_ass2;

public class student {

    String masv, name, email, phone, address, image;
    boolean gender;

    public student() {
    }

    public student(String masv, String name, String email, String phone, String address, String image, boolean gender) {
        this.masv = masv;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.image = image;
        this.gender = gender;
    }

    student(String masv, String name, String email, String phone, boolean gender, String address, String image) {
this.masv = masv;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.image = image;
        this.gender = gender;    }

   
    

    public void setMasv(String masv) {
        this.masv = masv;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setGender(boolean gender) {
        this.gender = gender;
    }

    public String getMasv() {
        return masv;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    public String getImage() {
        return image;
    }

    public boolean isGender() {
        return gender;
    }

    @Override
    public String toString() {
        return "student{" + "masv=" + masv + ", name=" + name + ", email=" + email + ", phone=" + phone + ", address=" + address + ", image=" + image + ", gender=" + gender + '}';
    }

}
