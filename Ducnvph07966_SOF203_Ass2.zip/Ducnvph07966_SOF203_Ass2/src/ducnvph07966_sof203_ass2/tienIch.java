
package ducnvph07966_sof203_ass2;

import assignment1.*;
import java.sql.Connection;
import java.sql.DriverManager;


public class tienIch {
     public static Connection ketnoi(){
        Connection cn=null;
        try {
            String username="sa";
            String pass="123";
            String url="jdbc:sqlserver://localhost:1433;databaseName=CSDL";
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            cn= DriverManager.getConnection(url, username, pass);
            return cn;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        
    }
}
